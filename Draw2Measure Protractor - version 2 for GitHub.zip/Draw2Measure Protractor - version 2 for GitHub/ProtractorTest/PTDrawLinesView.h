
#import <UIKit/UIKit.h>
#import "PTLine.h"

@interface PTDrawLinesView : UIView
-(void) drawUpdate: (NSMutableDictionary *) dictionary lineOne: (PTLine *) lineOne lineTwo: (PTLine *) lineTwo;
@end
