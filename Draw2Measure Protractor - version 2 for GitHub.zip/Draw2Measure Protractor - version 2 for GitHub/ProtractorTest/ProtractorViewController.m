
#import "ProtractorViewController.h"
#import "PTLine.h"
#import "PTHomeViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import "PTDrawLinesView.h"

@interface ProtractorViewController ()
@property (nonatomic, weak) IBOutlet UILabel *myLabel;
@property (strong, nonatomic) NSMutableDictionary *linesInProgress;
@property (nonatomic, strong) PTLine *lineOne;
@property (nonatomic, strong) PTLine *lineTwo;
@property (nonatomic) BOOL screenTouchOn;
@property (nonatomic, strong) NSTimer *myTimer;
@property (nonatomic, copy) NSString *myInstruction;
@property (nonatomic) SystemSoundID soundObject;
@property (nonatomic, strong) PTDrawLinesView *myDrawLinesView;
@end

@implementation ProtractorViewController

-(instancetype) initWithNibName: (NSString *) nibName bundle: (NSBundle *) nibBundle
{
self = [super initWithNibName: nibName bundle: nibBundle];
if (self)
{
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter addObserver: self selector: @selector(updateFonts) name: UIContentSizeCategoryDidChangeNotification object: nil];
UITapGestureRecognizer *tripleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(tripleTap:)];
tripleTapRecognizer.numberOfTapsRequired = 3;
[self.view addGestureRecognizer: tripleTapRecognizer];
}
return self;
}

-(void) dealloc
{
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter removeObserver: self];
AudioServicesDisposeSystemSoundID (self.soundObject);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
self.view.multipleTouchEnabled= YES;
self.view.isAccessibilityElement = YES;
self.view.accessibilityTraits = UIAccessibilityTraitAllowsDirectInteraction;
self.screenTouchOn = NO;
self.linesInProgress = [[NSMutableDictionary alloc] init];
self.myLabel.text = @"  Place the angle on the screen. Then triple tap the screen to begin.";
self.myLabel.textColor = [UIColor whiteColor];
[self updateFonts];
self.view.backgroundColor = [UIColor blackColor];
[self setNeedsStatusBarAppearanceUpdate];
NSURL *soundURL = [[NSBundle mainBundle] URLForResource: @"Blop" withExtension: @"wav"];
AudioServicesCreateSystemSoundID ((__bridge CFURLRef)soundURL, &_soundObject);
self.myDrawLinesView = [[PTDrawLinesView alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
[self.view addSubview: self.myDrawLinesView];
}

-(void) viewDidAppear: (BOOL) animated
{
[super viewDidAppear: animated];
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
dispatch_get_main_queue(), ^{
if (UIAccessibilityIsVoiceOverRunning())
{
self.myInstruction = @"Place the angle on the screen. Then triple tap the screen to begin.";
UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, self.myInstruction);
self.myTimer = [NSTimer scheduledTimerWithTimeInterval: 10 target: self selector: @selector(postMyInstruction) userInfo: nil repeats: YES];
}
});
}

-(void) viewWillDisappear: (BOOL) animated
{
[super viewWillDisappear: animated];
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
}

-(void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *)event
{
if (self.screenTouchOn == NO)
{
return;
}
for (UITouch *t in touches)
{
CGPoint location = [t locationInView: self.view];
PTLine *line = [[PTLine alloc] init];
line.begin = location;
line.end = location;
line.distance = 0.0;
line.pointArray = [[NSMutableArray alloc] init];
NSValue *key = [NSValue valueWithNonretainedObject: t];
self.linesInProgress[key] = line;
}
}

-(void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event
{
if (self.screenTouchOn == NO)
{
return;
}
for (UITouch *t in touches)
{
NSValue *key = [NSValue valueWithNonretainedObject: t];
PTLine *line = self.linesInProgress[key];
CGPoint location = [t locationInView: self.view];
line.end = location;
[line.pointArray addObject: [NSValue valueWithCGPoint: location]];
float temporaryDistance = sqrt((line.end.x - line.begin.x)*(line.end.x - line.begin.x) + (line.end.y - line.begin.y)*(line.end.y - line.begin.y));
if (temporaryDistance > line.distance)
{
line.distance = temporaryDistance;
}
}
[self.myDrawLinesView drawUpdate: self.linesInProgress lineOne: self.lineOne lineTwo: self.lineTwo];
}

-(void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event
{
if (self.screenTouchOn == NO)
{
return;
}
PTLine *localLine = [[PTLine alloc] init];
localLine.distance = 0.0;
for (UITouch *t in touches)
{
NSValue *key = [NSValue valueWithNonretainedObject: t];
PTLine *line = self.linesInProgress[key];
if ((line.distance > 132.0) && (line.distance > localLine.distance))
{
localLine = line;
}
[self.linesInProgress removeObjectForKey: key];
}
if (localLine.distance > 0.0)
{
if (!self.lineOne)
{
self.lineOne = localLine;
self.myLabel.text = @"  First ray was drawn. Please draw the second ray. Triple tap the screen to cancel.";
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
if (UIAccessibilityIsVoiceOverRunning() == NO)
{
if (self.soundObject)
{
AudioServicesPlaySystemSound (self.soundObject);
}
} else {
self.myInstruction = @"First ray was drawn. Please draw the second ray. Triple tap the screen to cancel.";
UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, self.myInstruction);
self.myTimer = [NSTimer scheduledTimerWithTimeInterval: 10 target: self selector: @selector(postMyInstruction) userInfo: nil repeats: YES];
}
} else if (!self.lineTwo)
{
self.lineTwo = localLine;
self.myLabel.text = @"  Second ray was drawn. Triple tap the screen to get the measurement.";
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
if (UIAccessibilityIsVoiceOverRunning() == NO)
{
if (self.soundObject)
{
AudioServicesPlaySystemSound (self.soundObject);
}
} else {
self.myInstruction = @"Second ray was drawn. Triple tap the screen to get the measurement.";
UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, self.myInstruction);
self.myTimer = [NSTimer scheduledTimerWithTimeInterval: 10 target: self selector: @selector(postMyInstruction) userInfo: nil repeats: YES];
}
}
}
[self.myDrawLinesView drawUpdate: self.linesInProgress lineOne: self.lineOne lineTwo: self.lineTwo];
}

-(void) touchesCancelled: (NSSet *) touches withEvent: (UIEvent *) event
{
return;
}

-(void) tripleTap: (UIGestureRecognizer *) gestureRecognizer
{
if (self.screenTouchOn == NO)
{
self.screenTouchOn = YES;
self.myLabel.text = @"Please draw the first ray of the angle. Triple tap the screen to cancel.";
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
if (UIAccessibilityIsVoiceOverRunning() == NO)
{
if (self.soundObject)
{
AudioServicesPlaySystemSound (self.soundObject);
}
} else {
self.myInstruction = @"Please draw the first ray of the angle. Triple tap the screen to cancel.";
UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, self.myInstruction);
self.myTimer = [NSTimer scheduledTimerWithTimeInterval: 10 target: self selector: @selector(postMyInstruction) userInfo: nil repeats: YES];
}
} else {
PTHomeViewController *hvc = [PTHomeViewController sharedHome];
NSInteger n = 0;
NSInteger m = 0;
if (self.lineOne.pointArray)
{
n = [self.lineOne.pointArray count];
if (self.lineTwo.pointArray)
{
m = [self.lineTwo.pointArray count];
}
}
if ((n > 15) && (m > 15))
{
NSValue *tenthValue = [self.lineOne.pointArray objectAtIndex: 5];
NSValue *ninethValue = [self.lineOne.pointArray objectAtIndex: 4];
NSValue *eighthValue = [self.lineOne.pointArray objectAtIndex: 3];
CGPoint tenthPoint = [tenthValue CGPointValue];
CGPoint ninethPoint = [ninethValue CGPointValue];
CGPoint eighthPoint = [eighthValue CGPointValue];
self.lineOne.begin = CGPointMake((tenthPoint.x + ninethPoint.x + eighthPoint.x) /3, (tenthPoint.y + ninethPoint.y + eighthPoint.y) / 3);

NSValue *xValue = [self.lineOne.pointArray objectAtIndex: n-4];
NSValue *yValue = [self.lineOne.pointArray objectAtIndex: n-3];
NSValue *zValue = [self.lineOne.pointArray objectAtIndex: n-2];
CGPoint xPoint = [xValue CGPointValue];
CGPoint yPoint = [yValue CGPointValue];
CGPoint zPoint = [zValue CGPointValue];
self.lineOne.end = CGPointMake((xPoint.x + yPoint.x + zPoint.x) / 3, (xPoint.y + yPoint.y + zPoint.y) / 3);

NSValue *tenthValueTwo = [self.lineTwo.pointArray objectAtIndex: 5];
NSValue *ninethValueTwo = [self.lineTwo.pointArray objectAtIndex: 4];
NSValue *eighthValueTwo = [self.lineTwo.pointArray objectAtIndex: 3];
CGPoint tenthPointTwo = [tenthValueTwo CGPointValue];
CGPoint ninethPointTwo = [ninethValueTwo CGPointValue];
CGPoint eighthPointTwo = [eighthValueTwo CGPointValue];
self.lineTwo.begin = CGPointMake((tenthPointTwo.x + ninethPointTwo.x + eighthPointTwo.x) /3, (tenthPointTwo.y + ninethPointTwo.y + eighthPointTwo.y) / 3);

NSValue *xValueTwo = [self.lineTwo.pointArray objectAtIndex: m-4];
NSValue *yValueTwo = [self.lineTwo.pointArray objectAtIndex: m-3];
NSValue *zValueTwo = [self.lineTwo.pointArray objectAtIndex: m-2];
CGPoint xPointTwo = [xValueTwo CGPointValue];
CGPoint yPointTwo = [yValueTwo CGPointValue];
CGPoint zPointTwo = [zValueTwo CGPointValue];
self.lineTwo.end = CGPointMake((xPointTwo.x + yPointTwo.x + zPointTwo.x) / 3, (xPointTwo.y + yPointTwo.y + zPointTwo.y) / 3);

float angle = [self angleBetween: self.lineOne and: self.lineTwo];
hvc.titleLabel.text = [NSString stringWithFormat: @"The angle is %.f degrees, %.02f radians.", angle * 180 / M_PI, round(angle * 180 / M_PI) * M_PI / 180];
} else {
hvc.titleLabel.text = [NSString stringWithFormat: @"Please try again."];
}
self.lineOne = nil;
self.lineTwo = nil;
self.linesInProgress = nil;
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
[self.presentingViewController dismissViewControllerAnimated: NO completion: nil];
}
}

-(float) angleBetween: (PTLine *) lineOne and: (PTLine *) lineTwo
{
float p, q;
p = lineOne.begin.x - lineTwo.begin.x;
q = lineOne.begin.y - lineTwo.begin.y;
lineTwo.end = CGPointMake( lineTwo.end.x + p, lineTwo.end.y + q );
float a, b, c;
a = sqrt((lineOne.end.x - lineOne.begin.x)*(lineOne.end.x - lineOne.begin.x) + (lineOne.end.y - lineOne.begin.y)*(lineOne.end.y - lineOne.begin.y));
b = sqrt((lineTwo.end.x - lineOne.begin.x)*(lineTwo.end.x - lineOne.begin.x) + (lineTwo.end.y - lineOne.begin.y)*(lineTwo.end.y - lineOne.begin.y));
c = sqrt((lineOne.end.x - lineTwo.end.x)*(lineOne.end.x - lineTwo.end.x) + (lineOne.end.y - lineTwo.end.y)*(lineOne.end.y - lineTwo.end.y));
float angle;
angle = acos( (a*a + b*b - c*c)/(2*a*b)  );
return angle;
}

-(void) updateFonts
{
UIFont *font = [UIFont preferredFontForTextStyle: UIFontTextStyleBody];
self.myLabel.font = font;
}

-(void) postMyInstruction
{
UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, self.myInstruction);
}

-(BOOL)prefersStatusBarHidden
{
return YES;
}

@end

