
#import "AppDelegate.h"
#import "PTHomeViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions 
{
self.window = [[UIWindow alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
PTHomeViewController *hvc = [PTHomeViewController sharedHome];
self.window.rootViewController = hvc;
self.window.backgroundColor = [UIColor blackColor];
[self.window makeKeyAndVisible];
return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application 
{
PTHomeViewController *hvc = [PTHomeViewController sharedHome];
hvc.titleLabel.text = @"Draw2Measure Protractor";
[hvc dismissView];
}

@end
