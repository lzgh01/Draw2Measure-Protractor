
//The sound effect "Blop" was retrieved from SoundBible.com on June 2nd, 2016 at http://soundbible.com/2067-Blop.html. As stated on the website, the sound is free to use under Attribution 3.0 license.


#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

