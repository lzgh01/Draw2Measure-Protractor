
#import "PTGyroViewController.h"
#import <CoreMotion/CoreMotion.h>
#import "PTHomeViewController.h"

@interface PTGyroViewController ()
@property (nonatomic) BOOL testingOn;
@property (nonatomic, strong) CMMotionManager *myMotionManager;
@property (nonatomic, strong) NSTimer *myTimer;
@property (nonatomic, strong) NSTimer *myTimer2;
@property (nonatomic, weak) IBOutlet UILabel *myLabel;
@property (nonatomic, weak) IBOutlet UIButton *startButton;
@property (nonatomic, weak) IBOutlet UIButton *backButton;
@end

@implementation PTGyroViewController

-(instancetype) initWithNibName: (NSString *) nibName bundle: (NSBundle *) nibBundle
{
self = [super initWithNibName: nibName bundle: nibBundle];
if (self)
{
self.myMotionManager = [[CMMotionManager alloc] init];
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter addObserver: self selector: @selector(updateFonts) name: UIContentSizeCategoryDidChangeNotification object: nil];
}
return self;
}

-(void) dealloc
{
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter removeObserver: self];
}

-(void) updateFonts
{
UIFont *font = [UIFont preferredFontForTextStyle: UIFontTextStyleBody];
self.myLabel.font = font;
self.startButton.titleLabel.font = font;
self.backButton.titleLabel.font = font;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
self.testingOn = NO;
self.myLabel.text = @"When ready, press the Start button. Then rotate your device horizontally to measure the angle.";
self.myLabel.textColor = [UIColor whiteColor];
[self updateFonts];
self.view.backgroundColor = [UIColor blackColor];
[self setNeedsStatusBarAppearanceUpdate];
}

-(void) viewWillDisappear: (BOOL) animated
{
[super viewWillDisappear: animated];
if (self.myMotionManager.deviceMotionActive)
{
[self.myMotionManager stopDeviceMotionUpdates];
}
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
if (self.myTimer2)
{
[self.myTimer2 invalidate];
self.myTimer2 = nil;
}
}

-(IBAction) back: (id) sender
{
PTHomeViewController *hvc = [PTHomeViewController sharedHome];
hvc.titleLabel.text = @"Draw2Measure Protractor";
[self.presentingViewController dismissViewControllerAnimated: YES completion: nil];
}

-(IBAction) start: (id) sender
{
if (self.testingOn == NO)
{
if (self.myMotionManager.deviceMotionAvailable == NO)
{
self.myLabel.text = @"Gyroscope sensor is not available on this device.";
if (UIAccessibilityIsVoiceOverRunning())
{
UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.myLabel);
}
} else {
self.testingOn = YES;
[self.myMotionManager startDeviceMotionUpdates];
self.myTimer = [NSTimer scheduledTimerWithTimeInterval: 0.2 target: self selector: @selector(updateAngle) userInfo: nil repeats: YES];
[self.startButton setTitle: @"Stop" forState: UIControlStateNormal];
if (UIAccessibilityIsVoiceOverRunning())
{
self.myTimer2 = [NSTimer scheduledTimerWithTimeInterval: 2.5 target: self selector: @selector(updateMeasurement) userInfo: nil repeats: YES];
}
}
} else if (self.testingOn == YES)
{
if (self.myMotionManager.deviceMotionActive)
{
[self.myMotionManager stopDeviceMotionUpdates];
}
if (self.myTimer)
{
[self.myTimer invalidate];
self.myTimer = nil;
}
if (self.myTimer2)
{
[self.myTimer2 invalidate];
self.myTimer2 = nil;
}
self.testingOn = NO;
[self.startButton setTitle: @"Measure Again" forState: UIControlStateNormal];
if (UIAccessibilityIsVoiceOverRunning())
{
UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.myLabel);
}
} 
}

-(void) updateAngle
{
if (self.myMotionManager.deviceMotionActive)
{
float angle = self.myMotionManager.deviceMotion.attitude.yaw * 180 / M_PI;
self.myLabel.text = [NSString stringWithFormat: @"%.f degrees, %.02f radians.", fabs(angle), round(fabs(angle)) * M_PI / 180];
}
}

-(void) updateMeasurement
{
UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, self.myLabel.text);
}

-(UIStatusBarStyle) preferredStatusBarStyle
{
return UIStatusBarStyleLightContent;
}


@end

