
#import <UIKit/UIKit.h>

@interface PTHomeViewController : UIViewController
@property (nonatomic, weak) IBOutlet UILabel *titleLabel;
+(instancetype) sharedHome;
-(void) dismissView;
@end
