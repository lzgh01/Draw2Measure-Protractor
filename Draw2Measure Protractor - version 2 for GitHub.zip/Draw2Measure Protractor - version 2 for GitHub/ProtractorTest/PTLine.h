
#import <UIKit/UIKit.h>

@interface PTLine : NSObject
@property (nonatomic) CGPoint begin;
@property (nonatomic) CGPoint end;
@property (nonatomic) float distance;
@property (nonatomic, strong) NSMutableArray *pointArray;
@end
