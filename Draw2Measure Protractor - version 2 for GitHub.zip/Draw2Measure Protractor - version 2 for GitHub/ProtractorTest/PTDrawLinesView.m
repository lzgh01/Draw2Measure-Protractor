
#import "PTDrawLinesView.h"

@interface PTDrawLinesView ()
@property (strong, nonatomic) NSMutableDictionary *linesInProgress;
@property (nonatomic, strong) PTLine *lineOne;
@property (nonatomic, strong) PTLine *lineTwo;
@end

@implementation PTDrawLinesView

-(instancetype) initWithFrame: (CGRect) frame
{
self = [super initWithFrame: frame];
if (self)
{
self.multipleTouchEnabled= YES;
self.isAccessibilityElement = YES;
self.accessibilityTraits = UIAccessibilityTraitAllowsDirectInteraction;
self.linesInProgress = [[NSMutableDictionary alloc] init];
self.backgroundColor = [UIColor clearColor];
}
return self;
}

-(void) drawUpdate: (NSMutableDictionary *) dictionary lineOne: (PTLine *) lineOne lineTwo: (PTLine *) lineTwo
{
self.linesInProgress = dictionary;
self.lineOne = lineOne;
self.lineTwo = lineTwo;
[self setNeedsDisplay];
}

-(void) strokeLine: (PTLine *) line
{
UIBezierPath *bp = [UIBezierPath bezierPath];
bp.lineWidth = 20;
bp.lineCapStyle = kCGLineCapRound;
[bp moveToPoint: line.begin];
[bp addLineToPoint: line.end];
[bp stroke];
}

-(void) drawRect: (CGRect) rect
{
[[UIColor yellowColor] set];
for (NSValue *key in self.linesInProgress)
{
[self strokeLine: self.linesInProgress[key]];
}
[[UIColor whiteColor] set];
if (self.lineOne)
{
[self strokeLine: self.lineOne];
}
if (self.lineTwo)
{
[self strokeLine: self.lineTwo];
}
}

@end
