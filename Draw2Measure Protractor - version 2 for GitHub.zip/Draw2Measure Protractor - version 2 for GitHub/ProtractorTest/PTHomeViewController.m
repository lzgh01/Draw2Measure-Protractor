
#import "PTHomeViewController.h"
#import "ProtractorViewController.h"
#import "PTInstructionViewController.h"
#import "PTGyroViewController.h"

@interface PTHomeViewController ()
@property (nonatomic, weak) IBOutlet UIButton *howToUseButton;
@property (nonatomic, weak) IBOutlet UIButton *drawingButton;
@property (nonatomic, weak) IBOutlet UIButton *rotationButton;
@end

@implementation PTHomeViewController

-(instancetype) initWithNibName: (NSString *) nibName bundle: (NSBundle *) nibBundle
{
self = [super initWithNibName: nibName bundle: nibBundle];
if (self)
{
self.view.backgroundColor = [UIColor blackColor];
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter addObserver: self selector: @selector(updateFonts) name: UIContentSizeCategoryDidChangeNotification object: nil];
}
return self;
}

-(void) dealloc
{
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter removeObserver: self];
}

+(instancetype) sharedHome
{
static PTHomeViewController *sharedHome = nil;
if (!sharedHome)
{
sharedHome = [[self alloc] init];
}
return sharedHome;
}

- (void)viewDidLoad {
    [super viewDidLoad];
self.titleLabel.text = @"Draw2Measure Protractor";
self.titleLabel.textColor = [UIColor whiteColor];
[[UIButton appearance] setTitleColor: [UIColor blackColor] forState: UIControlStateNormal];
[[UIButton appearance] setBackgroundColor: [UIColor whiteColor]];
[self setNeedsStatusBarAppearanceUpdate];
}

-(void) viewWillAppear: (BOOL) animated
{
[super viewWillAppear: animated];
[self updateFonts];
}

-(void) viewDidAppear: (BOOL) animated
{
[super viewDidAppear: animated];
if (UIAccessibilityIsVoiceOverRunning() == YES)
{
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
dispatch_get_main_queue(), ^{
UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.titleLabel);
});
}
}

-(IBAction) howToUse: (id) sender
{
PTInstructionViewController *ivc = [[PTInstructionViewController alloc] init];
[self presentViewController: ivc animated: YES completion: nil];
}

-(IBAction) measureByDrawing: (id) sender
{
ProtractorViewController *pvc = [[ProtractorViewController alloc] init];
[self presentViewController: pvc animated: YES completion: nil];
}

-(IBAction) measureByRotating: (id) sender
{
PTGyroViewController *gvc = [[PTGyroViewController alloc] init];
[self presentViewController: gvc animated: YES completion: nil];
}

-(void) updateFonts
{
UIFont *font = [UIFont preferredFontForTextStyle: UIFontTextStyleBody];
self.titleLabel.font = font;
self.howToUseButton.titleLabel.font = font;
self.drawingButton.titleLabel.font = font;
self.rotationButton.titleLabel.font = font;
}

-(void) dismissView
{
if (self.presentedViewController)
{
[self dismissViewControllerAnimated: YES completion: nil];
}
}

-(UIStatusBarStyle) preferredStatusBarStyle
{
return UIStatusBarStyleLightContent;
}

@end

