
#import "PTInstructionViewController.h"
#import "Reachability.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@interface PTInstructionViewController ()
@property (nonatomic, weak) IBOutlet UITextView *instructionText;
@property (nonatomic, weak) IBOutlet UIButton *backButton;
@property (nonatomic, weak) IBOutlet UIButton *videoButton;
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerViewController *playerViewController;
@end

@implementation PTInstructionViewController

-(instancetype) initWithNibName: (NSString *) nibName bundle: (NSBundle *) nibBundle
{
self = [super initWithNibName: nibName bundle: nibBundle];
if (self)
{
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter addObserver: self selector: @selector(updateFonts) name: UIContentSizeCategoryDidChangeNotification object: nil];
}
return self;
}

-(void) dealloc
{
NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
[defaultCenter removeObserver: self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
self.view.backgroundColor = [UIColor blackColor];
self.instructionText.text = @"    To use this app on iPad, turn off Gesture in Settings. For a large font size, adjust the Accessibility setting of your device. If the app is to be used by students who are blind, turn on VoiceOver on your device.\n\n    This protractor app allows you to measure angles in two ways: either by rotating your device or by drawing angles on your device screen. If you have internet access, you can click the Video Demonstration button below to learn how to use this app.\n\n    To measure an angle by rotating your device, place the angle and your device on a horizontal surface or desktop. Then, turn on the app and click Measure by Rotating. Move your device so that one side of it is parallel to one ray of the angle you want to measure, and then click Start. Next, rotate your device until the same side of the device becomes parallel to the second ray of the angle. It is important to keep your device horizontal while rotating. When finished, click Stop to get the measurement.\n\n    To measure an angle by drawing, follow the steps below:\n\n    a. Turn on the app and click Measure by Drawing.\n\n    b. Place the angle you want to measure on your device screen. To prevent the angle from slipping, you can cover the screen with a thin plastic sheet (e.g., food wrap).\n\n    c. Triple-tap the screen to continue.\n\n    d. Draw the first line on the screen by tracing your finger or a stylus along one ray of the angle. Although you can use a finger tip, a stylus gives you more accurate and reliable results and therefore is strongly recommended. First, identify a starting point with the stylus or your finger tip. After you find a starting point, lift the tip of your drawing finger or stylus away from the screen and then put it back on the screen to begin drawing. This is an important step to refresh the memory of the app. The line you drawn must be at least 1 in. long to be recognized by the app. For a straight and accurate line, you should both start and stop on the side of the angle, always stopping before reaching the angle vertex. You may draw either toward or away from the angle vertex. Use your other fingers to fix the angle to the screen so that it does not move while you draw.\n\n    e. Draw the second line by tracing the other ray of the angle. Follow the instructions from step d. Note that although you can choose to draw toward or away from the angle vertex, you must draw both lines in the same direction.\n\n    f. Lastly, remove all fingers from the screen, and triple-tap the screen to get the measurement. To measure the angle again, tap Measure by Drawing.";
self.instructionText.editable = NO;
self.instructionText.textColor = [UIColor whiteColor];
self.instructionText.backgroundColor = [UIColor blackColor];
self.instructionText.selectable = NO;
[self updateFonts];
[self setNeedsStatusBarAppearanceUpdate];
}

-(IBAction) back: (id) sender
{
[self.presentingViewController dismissViewControllerAnimated: YES completion: nil];
}

-(IBAction) playVideo: (id) sender
{
if (self.instructionText.hidden == NO)
{
Reachability *networkReachability = [Reachability reachabilityForLocalWiFi];
NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
if (networkStatus != ReachableViaWiFi)
{
UIAlertView *internetAlert = [[UIAlertView alloc] initWithTitle: @"Alert" message: @"No WiFi Connection" delegate: nil cancelButtonTitle: @"OK" otherButtonTitles: nil];
[internetAlert show];
} else {
self.instructionText.hidden = YES;
[self.videoButton setTitle: @"Close Video" forState: UIControlStateNormal];
NSURL *url = [NSURL URLWithString: @"http://www.aph.org/media/videos/TP01.mp4"];
self.player = [AVPlayer playerWithURL: url];
self.player.actionAtItemEnd = AVPlayerActionAtItemEndPause;
self.playerViewController = [[AVPlayerViewController alloc] init];
self.playerViewController.player = self.player;
self.playerViewController.view.frame = self.instructionText.frame;
[self addChildViewController: self.playerViewController];
[self.view addSubview: self.playerViewController.view];
[self.player play];
}
} else if (self.instructionText.hidden == YES)
{
if (self.player)
{
[self.player pause];
self.player = nil;
}
if (self.playerViewController)
{
[self.playerViewController.view removeFromSuperview];
[self.playerViewController removeFromParentViewController];
}
self.instructionText.hidden = NO;
[self.videoButton setTitle: @"Video Demonstration" forState: UIControlStateNormal];
}
}

-(void) updateFonts
{
UIFont *font = [UIFont preferredFontForTextStyle: UIFontTextStyleBody];
self.instructionText.font = font;
self.backButton.titleLabel.font = font;
self.videoButton.titleLabel.font = font;
}

-(UIStatusBarStyle) preferredStatusBarStyle
{
return UIStatusBarStyleLightContent;
}

@end
